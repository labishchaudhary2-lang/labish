const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

const state = {
  anime: [],
  stats: { users: 0, ratings: 0, catalog: 0, average: 0 },
  activity: [],
  user: null,
  query: "",
  genre: "All",
  sort: "trending",
  activeAnime: null,
};

const icons = {
  search: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.6-3.6"/></svg>`,
  star: `<svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="m12 2.4 2.9 5.9 6.5.9-4.7 4.6 1.1 6.5-5.8-3-5.8 3 1.1-6.5-4.7-4.6 6.5-.9L12 2.4Z"/></svg>`,
  arrow: `<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M5 12h14M13 6l6 6-6 6"/></svg>`,
  user: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="8" r="4"/><path d="M4.5 21a7.5 7.5 0 0 1 15 0"/></svg>`,
  play: `<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>`,
};

function escapeHTML(value = "") {
  return String(value).replace(/[&<>'"]/g, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" })[char]);
}

async function api(url, options = {}) {
  const response = await fetch(url, {
    credentials: "same-origin",
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    ...options,
  });
  let data;
  try { data = await response.json(); } catch { data = { error: "The server returned an invalid response." }; }
  if (!response.ok) throw new Error(data.error || "Something went wrong.");
  return data;
}

function compact(value) {
  return Intl.NumberFormat("en", { notation: "compact", maximumFractionDigits: 1 }).format(Number(value || 0));
}

function toast(message) {
  const el = $("#toast");
  el.textContent = message;
  el.classList.add("show");
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => el.classList.remove("show"), 2800);
}

function scoreText(score) {
  return Number(score || 0).toFixed(1);
}

async function init() {
  renderShell();
  bindGlobalEvents();
  try {
    const [catalog, stats, activity, me] = await Promise.all([
      api("/api/anime"), api("/api/stats"), api("/api/activity"), api("/api/me")
    ]);
    state.anime = catalog.anime;
    state.stats = stats;
    state.activity = activity.activity;
    state.user = me.user;
    renderAll();
  } catch (error) {
    toast(error.message);
    $("#animeGrid").innerHTML = `<div class="empty">Could not connect to AnimeVerse. Please refresh the page.</div>`;
  }
}

function renderShell() {
  document.body.innerHTML = `
    <div class="noise"></div>
    <header class="header">
      <a class="brand" href="#top" aria-label="AnimeVerse home">
        <span class="brand-mark">A</span><span class="brand-name">Anime<span>Verse</span></span>
      </a>
      <nav class="nav" aria-label="Main navigation">
        <a class="active" href="#top">Home</a><a href="#discover">Discover</a><a href="#rankings">Rankings</a><a href="#community">Community</a>
      </nav>
      <div class="header-spacer"></div>
      <label class="search-wrap">${icons.search}<input class="search" data-search type="search" placeholder="Search the verse..." aria-label="Search anime"></label>
      <button id="authBtn" class="btn btn-primary btn-small">${icons.user}<span class="label">Sign in</span></button>
      <button id="profileBtn" class="btn user-button" hidden aria-label="Open profile">A</button>
    </header>

    <main id="top">
      <div class="shell">
        <section class="hero" aria-labelledby="heroTitle">
          <div class="hero-media"><img src="/static/animeverse_hero.jpg" alt="Original anime heroine looking over a neon city"></div>
          <div class="hero-overlay"></div>
          <div class="hero-copy">
            <div class="eyebrow"><span class="pulse"></span>The next story is waiting</div>
            <h1 id="heroTitle">Find your next <span class="gradient">obsession.</span></h1>
            <p>Track every episode, share your scores, and discover original worlds loved by a growing community of anime fans.</p>
            <div class="hero-actions">
              <button class="btn btn-primary" data-scroll="discover">Explore the catalog ${icons.arrow}</button>
              <button class="btn btn-ghost" id="heroRandom">${icons.play} Surprise me</button>
            </div>
            <div class="hero-stats">
              <div class="hero-stat"><strong id="statCatalog">—</strong><span>Original titles</span></div>
              <div class="hero-stat"><strong id="statRatings">—</strong><span>Community scores</span></div>
              <div class="hero-stat"><strong id="statUsers">—</strong><span>Explorers</span></div>
            </div>
          </div>
          <div class="hero-rank"><div class="score" id="heroAverage">—</div><div><strong>Community pulse</strong><span>Average rating across the verse</span></div></div>
        </section>

        <section class="section" id="discover">
          <div class="section-heading">
            <div><div class="kicker">Explore the multiverse</div><h2>Discover your next story</h2><p class="section-subtitle"><span id="resultCount">0</span> titles from original worlds.</p></div>
            <div class="controls"><label class="catalog-search-wrap">${icons.search}<input class="search" data-search type="search" placeholder="Search anime..." aria-label="Search anime catalog"></label><select class="select" id="sortSelect" aria-label="Sort catalog"><option value="trending">Trending now</option><option value="score">Highest rated</option><option value="newest">Newest first</option><option value="title">Title A–Z</option></select></div>
          </div>
          <div class="chips" id="genreChips"></div>
          <div class="discovery-layout">
            <div class="anime-grid" id="animeGrid"><div class="empty skeleton">Loading the verse...</div></div>
            <aside class="rank-panel" id="rankings">
              <div class="rank-head"><h3>Top of the Verse</h3><p>Community favorites, live from shared ratings.</p></div>
              <div class="rank-list" id="rankList"></div>
            </aside>
          </div>
        </section>

        <section class="section" id="community">
          <div class="section-heading"><div><div class="kicker">Shared in real time</div><h2>The community pulse</h2><p class="section-subtitle">Every score shapes what rises next.</p></div></div>
          <div class="community-wrap">
            <article class="community-card"><h3>Fresh activity</h3><p>Latest ratings from explorers across AnimeVerse.</p><div class="activity" id="activityList"></div></article>
            <article class="community-card"><h3>One shared universe</h3><p>Real accounts. Persistent watchlists. Scores that matter.</p><div class="stat-orbit"><div class="orbit"><span class="orbit-dot"></span><span class="orbit-dot two"></span><div class="orbit-core"><strong id="orbitRatings">0</strong><span>ratings & counting</span></div></div></div></article>
          </div>
        </section>
      </div>
    </main>

    <footer class="footer"><div class="shell footer-inner"><a class="brand" href="#top"><span class="brand-mark">A</span><span class="brand-name">Anime<span>Verse</span></span></a><small>Original anime concepts & artwork · Built for discovery</small><small>© 2026 AnimeVerse</small></div></footer>

    <dialog class="modal" id="authModal"></dialog>
    <dialog class="modal" id="detailModal"></dialog>
    <dialog class="modal" id="profileModal"></dialog>
    <div class="toast" id="toast" role="status" aria-live="polite"></div>`;
}

function renderAll() {
  renderSession();
  renderStats();
  renderGenres();
  renderCatalog();
  renderRankings();
  renderActivity();
}

function renderSession() {
  const auth = $("#authBtn");
  const profile = $("#profileBtn");
  if (state.user) {
    auth.hidden = true;
    profile.hidden = false;
    profile.textContent = state.user.username.charAt(0).toUpperCase();
    profile.title = `Open ${state.user.username}'s profile`;
  } else {
    auth.hidden = false;
    profile.hidden = true;
  }
}

function renderStats() {
  $("#statCatalog").textContent = compact(state.stats.catalog);
  $("#statRatings").textContent = compact(state.stats.ratings);
  $("#statUsers").textContent = compact(state.stats.users);
  $("#heroAverage").textContent = scoreText(state.stats.average);
  $("#orbitRatings").textContent = compact(state.stats.ratings);
}

function renderGenres() {
  const genres = ["All", ...new Set(state.anime.flatMap(item => item.genres))];
  $("#genreChips").innerHTML = genres.map(genre => `<button class="chip ${state.genre === genre ? "active" : ""}" data-genre="${escapeHTML(genre)}">${escapeHTML(genre)}</button>`).join("");
}

function visibleAnime() {
  const query = state.query.toLowerCase().trim();
  let items = state.anime.filter(item => {
    const matchGenre = state.genre === "All" || item.genres.includes(state.genre);
    const haystack = `${item.title} ${item.title_jp} ${item.genres.join(" ")} ${item.synopsis}`.toLowerCase();
    return matchGenre && (!query || haystack.includes(query));
  });
  return items.sort((a, b) => {
    if (state.sort === "score") return b.avg_score - a.avg_score || b.rating_count - a.rating_count;
    if (state.sort === "newest") return b.year - a.year || b.id - a.id;
    if (state.sort === "title") return a.title.localeCompare(b.title);
    return b.featured - a.featured || b.rating_count - a.rating_count || b.avg_score - a.avg_score;
  });
}

function renderCatalog() {
  const items = visibleAnime();
  $("#resultCount").textContent = items.length;
  if (!items.length) {
    $("#animeGrid").innerHTML = `<div class="empty"><strong>No portals found.</strong><br>Try a different title or genre.</div>`;
    return;
  }
  $("#animeGrid").innerHTML = items.map(item => `
    <article class="anime-card" style="--accent:${escapeHTML(item.accent)}" data-anime-id="${item.id}">
      <div class="card-cover">
        <img src="${escapeHTML(item.cover)}" alt="Original cover for ${escapeHTML(item.title)}" loading="lazy">
        ${item.status === "Airing" ? `<span class="airing">Airing</span>` : ""}
        <span class="score-badge">${icons.star}${scoreText(item.avg_score)}</span>
      </div>
      <div class="card-copy">
        <div class="card-title" title="${escapeHTML(item.title)}">${escapeHTML(item.title)}</div>
        <div class="card-jp">${escapeHTML(item.title_jp)}</div>
        <div class="card-meta"><div class="tags">${item.genres.slice(0,2).map(g => `<span class="tag">${escapeHTML(g)}</span>`).join("")}</div><span class="episodes">${item.episodes} eps</span></div>
        <button class="card-cta">${item.user_score ? `Your score · ${item.user_score}/10` : "Open details"}</button>
      </div>
    </article>`).join("");
}

function renderRankings() {
  const ranked = [...state.anime].sort((a,b) => b.avg_score - a.avg_score || b.rating_count - a.rating_count).slice(0,6);
  $("#rankList").innerHTML = ranked.map((item,index) => `
    <button class="rank-item" data-anime-id="${item.id}" style="border:0;width:100%;color:inherit;text-align:left;background-color:transparent">
      <span class="rank-number">${String(index + 1).padStart(2,"0")}</span>
      <img class="rank-cover" src="${escapeHTML(item.cover)}" alt="" loading="lazy">
      <span><span class="rank-title">${escapeHTML(item.title)}</span><span class="rank-genre">${escapeHTML(item.genres[0])} · ${item.year}</span></span>
      <span class="rank-score">${scoreText(item.avg_score)}</span>
    </button>`).join("");
}

function renderActivity() {
  const container = $("#activityList");
  if (!state.activity.length) {
    container.innerHTML = `<div class="empty">No activity yet. Be the first to rate a title.</div>`;
    return;
  }
  container.innerHTML = state.activity.slice(0,5).map(item => `
    <div class="activity-row">
      <img src="${escapeHTML(item.cover)}" alt="" loading="lazy">
      <div class="activity-copy"><strong>${escapeHTML(item.username)}</strong> rated <strong>${escapeHTML(item.title)}</strong></div>
      <div class="activity-score">${icons.star} ${item.score}/10</div>
    </div>`).join("");
}

function bindGlobalEvents() {
  document.addEventListener("click", event => {
    const scroll = event.target.closest("[data-scroll]");
    if (scroll) document.getElementById(scroll.dataset.scroll)?.scrollIntoView({ behavior:"smooth" });

    const animeTarget = event.target.closest("[data-anime-id]");
    if (animeTarget) {
      const parentDialog = animeTarget.closest("dialog[open]");
      if (parentDialog && parentDialog.id !== "detailModal") parentDialog.close();
      openDetails(Number(animeTarget.dataset.animeId));
    }

    const genre = event.target.closest("[data-genre]");
    if (genre) {
      state.genre = genre.dataset.genre;
      renderGenres(); renderCatalog();
    }

    const close = event.target.closest("[data-close]");
    if (close) close.closest("dialog")?.close();

    const authTab = event.target.closest("[data-auth-tab]");
    if (authTab) renderAuth(authTab.dataset.authTab);
  });

  document.addEventListener("click", event => {
    if (event.target.tagName === "DIALOG") event.target.close();
  });

  $$('[data-search]').forEach(input => input.addEventListener("input", event => {
    state.query = event.target.value;
    $$('[data-search]').forEach(other => { if (other !== event.target) other.value = state.query; });
    renderCatalog();
    if (state.query && event.target.closest("header")) document.getElementById("discover").scrollIntoView({ behavior:"smooth", block:"start" });
  }));
  $("#sortSelect").addEventListener("change", event => { state.sort = event.target.value; renderCatalog(); });
  $("#authBtn").addEventListener("click", () => openAuth("login"));
  $("#profileBtn").addEventListener("click", openProfile);
  $("#heroRandom").addEventListener("click", () => {
    const item = state.anime[Math.floor(Math.random() * state.anime.length)];
    if (item) openDetails(item.id);
  });
}

function openAuth(tab = "login") {
  renderAuth(tab);
  $("#authModal").showModal();
}

function renderAuth(tab) {
  const isLogin = tab === "login";
  $("#authModal").innerHTML = `
    <div class="modal-panel">
      <button class="modal-close" data-close aria-label="Close">×</button>
      <div class="kicker">Enter the verse</div>
      <h2 style="margin:7px 0 0;font-size:30px">${isLogin ? "Welcome back" : "Create your account"}</h2>
      <div class="auth-tabs"><button class="auth-tab ${isLogin ? "active" : ""}" data-auth-tab="login">Sign in</button><button class="auth-tab ${!isLogin ? "active" : ""}" data-auth-tab="register">Register</button></div>
      <form class="form" id="authForm">
        <div class="field"><label for="username">Username</label><input id="username" name="username" autocomplete="username" minlength="3" maxlength="20" required placeholder="cosmic_explorer"></div>
        <div class="field"><label for="password">Password</label><input id="password" name="password" type="password" autocomplete="${isLogin ? "current-password" : "new-password"}" minlength="6" required placeholder="At least 6 characters"></div>
        <div class="form-error" id="authError"></div>
        <button class="btn btn-primary" type="submit">${isLogin ? "Sign in" : "Join AnimeVerse"} ${icons.arrow}</button>
        <div class="form-note">${isLogin ? "Demo access: nova / demo123" : "Your account keeps ratings and watchlists synced in the shared database."}</div>
      </form>
    </div>`;
  $("#authForm").addEventListener("submit", event => submitAuth(event, tab));
}

async function submitAuth(event, tab) {
  event.preventDefault();
  const form = event.currentTarget;
  const button = $("button[type=submit]", form);
  const errorEl = $("#authError");
  button.disabled = true; button.textContent = tab === "login" ? "Signing in..." : "Creating account...";
  errorEl.textContent = "";
  try {
    const result = await api(`/api/${tab}`, { method:"POST", body:JSON.stringify({ username:form.username.value.trim(), password:form.password.value }) });
    state.user = result.user;
    $("#authModal").close();
    await refreshData();
    toast(tab === "login" ? `Welcome back, ${state.user.username}.` : `Welcome to AnimeVerse, ${state.user.username}!`);
  } catch (error) {
    errorEl.textContent = error.message;
    button.disabled = false; button.textContent = tab === "login" ? "Sign in" : "Join AnimeVerse";
  }
}

function openDetails(id) {
  const item = state.anime.find(anime => anime.id === id);
  if (!item) return;
  state.activeAnime = item;
  const modal = $("#detailModal");
  modal.innerHTML = `
    <div class="modal-panel modal-wide">
      <button class="modal-close" data-close aria-label="Close">×</button>
      <div class="detail">
        <div class="detail-cover"><img src="${escapeHTML(item.cover)}" alt="Original cover for ${escapeHTML(item.title)}"></div>
        <div class="detail-info">
          <div class="kicker">${item.status} · ${item.year}</div>
          <h2>${escapeHTML(item.title)}</h2><div class="detail-jp">${escapeHTML(item.title_jp)}</div>
          <div class="detail-pills">${item.genres.map(g => `<span class="detail-pill">${escapeHTML(g)}</span>`).join("")}<span class="detail-pill">${item.episodes} episodes</span></div>
          <p class="detail-synopsis">${escapeHTML(item.synopsis)}</p>
          <div class="score-row"><div><div class="big-score" id="modalAverage">${scoreText(item.avg_score)} <small>/ 10</small></div><div class="rating-label"><span id="modalRatingCount">${item.rating_count}</span> community ratings</div></div><div style="color:var(--gold);font-size:24px">${icons.star}</div></div>
          <div class="rating-label">${state.user ? "Choose your score" : "Sign in to add your score"}</div>
          <div class="rating-scale">${Array.from({length:10},(_,i) => `<button class="rate-btn ${item.user_score === i+1 ? "active" : ""}" data-rate="${i+1}">${i+1}</button>`).join("")}</div>
          <div class="rating-label" style="margin-bottom:8px">Add to your list</div>
          <div class="list-controls">${["Watching","Planning","Completed","Dropped"].map(status => `<button class="list-btn ${item.list_status === status ? "active" : ""}" data-list-status="${status}">${status}</button>`).join("")}</div>
        </div>
      </div>
    </div>`;
  $$('[data-rate]', modal).forEach(button => button.addEventListener("click", () => submitRating(item.id, Number(button.dataset.rate))));
  $$('[data-list-status]', modal).forEach(button => button.addEventListener("click", () => submitList(item.id, button.dataset.listStatus)));
  modal.showModal();
}

async function submitRating(id, score) {
  if (!state.user) { $("#detailModal").close(); openAuth("login"); toast("Sign in to rate this title."); return; }
  try {
    const result = await api(`/api/rate/${id}`, { method:"POST", body:JSON.stringify({ score }) });
    const item = state.anime.find(x => x.id === id);
    item.user_score = score; item.avg_score = result.average; item.rating_count = result.count;
    $$('[data-rate]', $("#detailModal")).forEach(btn => btn.classList.toggle("active", Number(btn.dataset.rate) === score));
    $("#modalAverage").innerHTML = `${scoreText(result.average)} <small>/ 10</small>`;
    $("#modalRatingCount").textContent = result.count;
    renderCatalog(); renderRankings();
    await refreshActivityAndStats();
    toast(`Your ${score}/10 score is live.`);
  } catch (error) { toast(error.message); }
}

async function submitList(id, status) {
  if (!state.user) { $("#detailModal").close(); openAuth("login"); toast("Sign in to build your list."); return; }
  try {
    await api(`/api/list/${id}`, { method:"POST", body:JSON.stringify({ status }) });
    const item = state.anime.find(x => x.id === id); item.list_status = status;
    $$('[data-list-status]', $("#detailModal")).forEach(btn => btn.classList.toggle("active", btn.dataset.listStatus === status));
    toast(`${item.title} added to ${status}.`);
  } catch (error) { toast(error.message); }
}

async function openProfile() {
  try {
    const profile = await api("/api/profile");
    const modal = $("#profileModal");
    modal.innerHTML = `<div class="modal-panel profile-panel">
      <button class="modal-close" data-close aria-label="Close">×</button>
      <div class="profile-head"><div class="avatar">${escapeHTML(profile.user.username.charAt(0).toUpperCase())}</div><div><div class="kicker">AnimeVerse explorer</div><h2>${escapeHTML(profile.user.username)}</h2><p>Member since ${new Date(profile.user.created_at).toLocaleDateString(undefined,{year:"numeric",month:"long"})}</p></div></div>
      <div class="profile-stats"><div class="profile-stat"><strong>${profile.rated}</strong><span>Titles rated</span></div><div class="profile-stat"><strong>${scoreText(profile.average)}</strong><span>Average score</span></div><div class="profile-stat"><strong>${profile.lists.length}</strong><span>On lists</span></div></div>
      <div style="display:flex;justify-content:space-between;align-items:center;margin:5px 0 12px"><strong style="font-size:14px">My watchlist</strong><button id="logoutBtn" class="btn btn-ghost btn-small">Sign out</button></div>
      <div class="profile-list">${profile.lists.length ? profile.lists.map(item => `<button class="profile-item" data-anime-id="${item.id}" style="border:0;color:inherit;text-align:left"><img src="${escapeHTML(item.cover)}" alt=""><strong>${escapeHTML(item.title)}</strong><span>${escapeHTML(item.status)}</span></button>`).join("") : `<div class="empty">Your watchlist is waiting for its first story.</div>`}</div>
    </div>`;
    $("#logoutBtn").addEventListener("click", logout);
    modal.showModal();
  } catch (error) { toast(error.message); }
}

async function logout() {
  try {
    await api("/api/logout", { method:"POST", body:"{}" });
    state.user = null;
    $("#profileModal").close();
    await refreshData();
    toast("You have signed out.");
  } catch (error) { toast(error.message); }
}

async function refreshData() {
  const [catalog, stats, activity, me] = await Promise.all([api("/api/anime"),api("/api/stats"),api("/api/activity"),api("/api/me")]);
  state.anime = catalog.anime; state.stats = stats; state.activity = activity.activity; state.user = me.user;
  renderAll();
}

async function refreshActivityAndStats() {
  const [stats, activity] = await Promise.all([api("/api/stats"),api("/api/activity")]);
  state.stats = stats; state.activity = activity.activity; renderStats(); renderActivity();
}

init();
