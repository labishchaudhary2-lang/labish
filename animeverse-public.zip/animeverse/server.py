#!/usr/bin/env python3
"""AnimeVerse demo server — standard-library only.

A small full-stack anime discovery/rating app with shared SQLite data,
account sessions, ratings, and watchlists. Designed for local demos.
"""
from __future__ import annotations

import argparse
import hashlib
import hmac
import json
import mimetypes
import os
import re
import secrets
import sqlite3
import time
from datetime import datetime, timezone
from http import HTTPStatus
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

ROOT = Path(__file__).resolve().parent
STATIC = ROOT / "static"
_db_override = os.environ.get("ANIMEVERSE_DB")
_volume_root = os.environ.get("RAILWAY_VOLUME_MOUNT_PATH")
DB_PATH = (
    Path(_db_override)
    if _db_override
    else Path(_volume_root) / "animeverse.db"
    if _volume_root
    else ROOT / "animeverse.db"
)
USERNAME_RE = re.compile(r"^[A-Za-z0-9_]{3,20}$")
SESSION_SECONDS = 60 * 60 * 24 * 14

ANIME = [
    (1, "Neon Ronin", "ネオン浪人", "A memory-wiped swordswoman hunts the corporation that turned her past into a weapon, one rain-soaked district at a time.", 2026, 12, "Airing", ["Action", "Sci-Fi"], "#8b5cf6", "/static/covers/01.svg", 1),
    (2, "Petalbound", "花に結ばれて", "Two rival shrine keepers awaken an ancient garden where every flower carries a forgotten promise.", 2025, 24, "Completed", ["Fantasy", "Romance"], "#ec4899", "/static/covers/02.svg", 1),
    (3, "Hollow Orbit", "虚ろな軌道", "The last students aboard a silent academy ship discover that their missing teachers may never have existed.", 2026, 10, "Airing", ["Mystery", "Sci-Fi"], "#06b6d4", "/static/covers/03.svg", 1),
    (4, "Crimson Vale", "紅の谷", "A gentle healer inherits a cursed blade that grows stronger each time she refuses to draw it.", 2024, 24, "Completed", ["Action", "Dark Fantasy"], "#ef4444", "/static/covers/04.svg", 0),
    (5, "Summer Signal", "夏の信号", "A broken radio connects five classmates to the summer they wish they could relive.", 2025, 12, "Completed", ["Romance", "Slice of Life"], "#f59e0b", "/static/covers/05.svg", 1),
    (6, "Spirit Circuit", "霊魂回路", "Street racers bind spirits to electric bikes and compete for one impossible wish.", 2026, 13, "Airing", ["Action", "Supernatural"], "#10b981", "/static/covers/06.svg", 0),
    (7, "The Last Bento Club", "最後の弁当部", "Four hopeless cooks have one semester to save their club—and accidentally become a family.", 2023, 12, "Completed", ["Comedy", "Slice of Life"], "#fb7185", "/static/covers/07.svg", 0),
    (8, "Echoes of Atlas", "アトラスの残響", "Children raised beneath a sleeping giant climb to the surface to learn why the sky is forbidden.", 2025, 24, "Completed", ["Adventure", "Drama"], "#3b82f6", "/static/covers/08.svg", 1),
    (9, "Moonlit Apothecary", "月夜の薬師", "A palace herbalist solves quiet mysteries while hiding the one poison she cannot cure.", 2026, 12, "Airing", ["Drama", "Mystery"], "#a78bfa", "/static/covers/09.svg", 0),
    (10, "Glass Comet", "硝子の彗星", "A courier crosses collapsing worlds to deliver a letter written at the end of time.", 2024, 13, "Completed", ["Adventure", "Sci-Fi"], "#22d3ee", "/static/covers/10.svg", 0),
    (11, "Crown of Cinders", "灰の王冠", "Three heirs enter a ruined capital; only the one who rejects the crown can restore it.", 2025, 24, "Completed", ["Drama", "Fantasy"], "#f97316", "/static/covers/11.svg", 0),
    (12, "Zero Hour Academy", "零時学園", "Every midnight, one classroom disappears. The students left behind are running out of rooms.", 2026, 12, "Airing", ["Mystery", "Thriller"], "#6366f1", "/static/covers/12.svg", 0),
]


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def connect() -> sqlite3.Connection:
    db = sqlite3.connect(DB_PATH)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA foreign_keys=ON")
    db.execute("PRAGMA journal_mode=WAL")
    return db


def hash_password(password: str, salt: bytes | None = None) -> tuple[str, str]:
    salt = salt or os.urandom(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 240_000)
    return salt.hex(), digest.hex()


def verify_password(password: str, salt_hex: str, expected_hex: str) -> bool:
    _, actual = hash_password(password, bytes.fromhex(salt_hex))
    return hmac.compare_digest(actual, expected_hex)


def init_db() -> None:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    with connect() as db:
        db.executescript(
            """
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL UNIQUE COLLATE NOCASE,
                salt TEXT NOT NULL,
                password_hash TEXT NOT NULL,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS anime (
                id INTEGER PRIMARY KEY,
                title TEXT NOT NULL,
                title_jp TEXT NOT NULL,
                synopsis TEXT NOT NULL,
                year INTEGER NOT NULL,
                episodes INTEGER NOT NULL,
                status TEXT NOT NULL,
                genres TEXT NOT NULL,
                accent TEXT NOT NULL,
                cover TEXT NOT NULL,
                featured INTEGER NOT NULL DEFAULT 0
            );
            CREATE TABLE IF NOT EXISTS ratings (
                user_id INTEGER NOT NULL,
                anime_id INTEGER NOT NULL,
                score INTEGER NOT NULL CHECK(score BETWEEN 1 AND 10),
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                PRIMARY KEY (user_id, anime_id),
                FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
                FOREIGN KEY(anime_id) REFERENCES anime(id) ON DELETE CASCADE
            );
            CREATE TABLE IF NOT EXISTS watchlist (
                user_id INTEGER NOT NULL,
                anime_id INTEGER NOT NULL,
                status TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                PRIMARY KEY (user_id, anime_id),
                FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
                FOREIGN KEY(anime_id) REFERENCES anime(id) ON DELETE CASCADE
            );
            CREATE TABLE IF NOT EXISTS sessions (
                token TEXT PRIMARY KEY,
                user_id INTEGER NOT NULL,
                expires_at INTEGER NOT NULL,
                FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
            );
            """
        )
        for item in ANIME:
            db.execute(
                """INSERT OR IGNORE INTO anime
                (id,title,title_jp,synopsis,year,episodes,status,genres,accent,cover,featured)
                VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
                (*item[:7], json.dumps(item[7]), *item[8:]),
            )

        # Seed a small community so aggregate ratings and activity are meaningful.
        seed_users = ["nova", "kaizen", "mika", "ren"]
        for username in seed_users:
            if not db.execute("SELECT 1 FROM users WHERE username=?", (username,)).fetchone():
                salt, digest = hash_password("demo123")
                db.execute(
                    "INSERT INTO users(username,salt,password_hash,created_at) VALUES (?,?,?,?)",
                    (username, salt, digest, now_iso()),
                )
        demo_scores = {
            "nova": [9, 8, 9, 8, 7, 9, 7, 9, 8, 8, 7, 9],
            "kaizen": [8, 9, 8, 9, 8, 8, 8, 9, 9, 7, 8, 8],
            "mika": [10, 9, 8, 7, 9, 8, 9, 8, 9, 8, 7, 8],
            "ren": [9, 8, 9, 8, 8, 9, 7, 10, 8, 9, 9, 7],
        }
        stamp = now_iso()
        for username, scores in demo_scores.items():
            uid = db.execute("SELECT id FROM users WHERE username=?", (username,)).fetchone()[0]
            for anime_id, score in enumerate(scores, start=1):
                db.execute(
                    "INSERT OR IGNORE INTO ratings(user_id,anime_id,score,created_at,updated_at) VALUES (?,?,?,?,?)",
                    (uid, anime_id, score, stamp, stamp),
                )


def create_session(db: sqlite3.Connection, user_id: int) -> str:
    token = secrets.token_urlsafe(32)
    db.execute("DELETE FROM sessions WHERE expires_at < ?", (int(time.time()),))
    db.execute(
        "INSERT INTO sessions(token,user_id,expires_at) VALUES (?,?,?)",
        (token, user_id, int(time.time()) + SESSION_SECONDS),
    )
    return token


class Handler(BaseHTTPRequestHandler):
    server_version = "AnimeVerse/1.0"

    def log_message(self, fmt: str, *args) -> None:
        print(f"[{self.log_date_time_string()}] {fmt % args}")

    def security_headers(self) -> None:
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "SAMEORIGIN")
        self.send_header("Referrer-Policy", "strict-origin-when-cross-origin")

    def json_response(self, data, status=200, cookie: str | None = None) -> None:
        body = json.dumps(data, separators=(",", ":")).encode()
        self.send_response(status)
        self.security_headers()
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        if cookie:
            self.send_header("Set-Cookie", cookie)
        self.end_headers()
        self.wfile.write(body)

    def read_json(self) -> dict:
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length > 100_000:
                raise ValueError("Request too large")
            return json.loads(self.rfile.read(length) or b"{}")
        except Exception as exc:
            raise ValueError("Invalid JSON") from exc

    def current_user(self, db: sqlite3.Connection):
        raw = self.headers.get("Cookie", "")
        cookie = SimpleCookie()
        try:
            cookie.load(raw)
            token = cookie.get("animeverse_session")
            if not token:
                return None
            row = db.execute(
                """SELECT u.id,u.username,u.created_at FROM sessions s
                JOIN users u ON u.id=s.user_id
                WHERE s.token=? AND s.expires_at>?""",
                (token.value, int(time.time())),
            ).fetchone()
            return row
        except Exception:
            return None

    def require_user(self, db: sqlite3.Connection):
        user = self.current_user(db)
        if not user:
            self.json_response({"error": "Sign in to use this feature."}, 401)
            return None
        return user

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        path = parsed.path
        if path.startswith("/api/"):
            self.handle_api_get(path, parse_qs(parsed.query))
            return
        self.serve_file(path)

    def serve_file(self, path: str) -> None:
        if path in ("/", "/index.html"):
            target = ROOT / "index.html"
        elif path.startswith("/static/"):
            target = (ROOT / path.lstrip("/")).resolve()
            if STATIC.resolve() not in target.parents:
                self.send_error(403)
                return
        else:
            target = ROOT / "index.html"  # client-side fallback
        if not target.exists() or not target.is_file():
            self.send_error(404)
            return
        content = target.read_bytes()
        ctype = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
        self.send_response(200)
        self.security_headers()
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(content)))
        self.send_header("Cache-Control", "public, max-age=300" if path.startswith("/static/") else "no-cache")
        self.end_headers()
        self.wfile.write(content)

    def handle_api_get(self, path: str, query: dict) -> None:
        with connect() as db:
            user = self.current_user(db)
            uid = user["id"] if user else 0
            if path == "/api/me":
                self.json_response({"user": dict(user) if user else None})
                return
            if path == "/api/stats":
                users = db.execute("SELECT COUNT(*) FROM users").fetchone()[0]
                ratings = db.execute("SELECT COUNT(*) FROM ratings").fetchone()[0]
                avg = db.execute("SELECT ROUND(AVG(score),1) FROM ratings").fetchone()[0] or 0
                self.json_response({"users": users, "ratings": ratings, "catalog": len(ANIME), "average": avg})
                return
            if path == "/api/anime":
                rows = db.execute(
                    """SELECT a.*,
                    ROUND(COALESCE(AVG(r.score),0),1) avg_score,
                    COUNT(r.score) rating_count,
                    ur.score user_score,
                    w.status list_status
                    FROM anime a
                    LEFT JOIN ratings r ON r.anime_id=a.id
                    LEFT JOIN ratings ur ON ur.anime_id=a.id AND ur.user_id=?
                    LEFT JOIN watchlist w ON w.anime_id=a.id AND w.user_id=?
                    GROUP BY a.id ORDER BY a.featured DESC, avg_score DESC, rating_count DESC""",
                    (uid, uid),
                ).fetchall()
                out = []
                for row in rows:
                    item = dict(row)
                    item["genres"] = json.loads(item["genres"])
                    out.append(item)
                self.json_response({"anime": out})
                return
            if path == "/api/activity":
                rows = db.execute(
                    """SELECT u.username,a.title,a.cover,r.score,r.updated_at
                    FROM ratings r JOIN users u ON u.id=r.user_id JOIN anime a ON a.id=r.anime_id
                    ORDER BY r.updated_at DESC, r.rowid DESC LIMIT 8"""
                ).fetchall()
                self.json_response({"activity": [dict(r) for r in rows]})
                return
            if path == "/api/profile":
                if not user:
                    self.json_response({"error": "Sign in first."}, 401)
                    return
                rated = db.execute("SELECT COUNT(*) FROM ratings WHERE user_id=?", (uid,)).fetchone()[0]
                avg = db.execute("SELECT ROUND(AVG(score),1) FROM ratings WHERE user_id=?", (uid,)).fetchone()[0] or 0
                lists = db.execute(
                    """SELECT w.status,a.id,a.title,a.cover,a.accent FROM watchlist w
                    JOIN anime a ON a.id=w.anime_id WHERE w.user_id=? ORDER BY w.updated_at DESC""",
                    (uid,),
                ).fetchall()
                self.json_response({"user": dict(user), "rated": rated, "average": avg, "lists": [dict(x) for x in lists]})
                return
            self.json_response({"error": "Not found"}, 404)

    def do_POST(self) -> None:
        path = urlparse(self.path).path
        try:
            payload = self.read_json()
        except ValueError as exc:
            self.json_response({"error": str(exc)}, 400)
            return
        with connect() as db:
            if path == "/api/register":
                username = str(payload.get("username", "")).strip()
                password = str(payload.get("password", ""))
                if not USERNAME_RE.fullmatch(username):
                    self.json_response({"error": "Username must be 3–20 letters, numbers, or underscores."}, 400)
                    return
                if len(password) < 6:
                    self.json_response({"error": "Password must contain at least 6 characters."}, 400)
                    return
                salt, digest = hash_password(password)
                try:
                    cur = db.execute(
                        "INSERT INTO users(username,salt,password_hash,created_at) VALUES (?,?,?,?)",
                        (username, salt, digest, now_iso()),
                    )
                except sqlite3.IntegrityError:
                    self.json_response({"error": "That username is already taken."}, 409)
                    return
                token = create_session(db, cur.lastrowid)
                db.commit()
                cookie = f"animeverse_session={token}; Path=/; HttpOnly; SameSite=Lax; Max-Age={SESSION_SECONDS}"
                self.json_response({"ok": True, "user": {"id": cur.lastrowid, "username": username}}, 201, cookie)
                return
            if path == "/api/login":
                username = str(payload.get("username", "")).strip()
                password = str(payload.get("password", ""))
                row = db.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
                if not row or not verify_password(password, row["salt"], row["password_hash"]):
                    self.json_response({"error": "Incorrect username or password."}, 401)
                    return
                token = create_session(db, row["id"])
                db.commit()
                cookie = f"animeverse_session={token}; Path=/; HttpOnly; SameSite=Lax; Max-Age={SESSION_SECONDS}"
                self.json_response({"ok": True, "user": {"id": row["id"], "username": row["username"]}}, 200, cookie)
                return
            if path == "/api/logout":
                raw = self.headers.get("Cookie", "")
                cookie_in = SimpleCookie(); cookie_in.load(raw)
                token = cookie_in.get("animeverse_session")
                if token:
                    db.execute("DELETE FROM sessions WHERE token=?", (token.value,))
                    db.commit()
                expired = "animeverse_session=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0"
                self.json_response({"ok": True}, 200, expired)
                return

            user = self.require_user(db)
            if not user:
                return
            uid = user["id"]
            match = re.fullmatch(r"/api/rate/(\d+)", path)
            if match:
                anime_id = int(match.group(1)); score = payload.get("score")
                if not isinstance(score, int) or not 1 <= score <= 10:
                    self.json_response({"error": "Score must be a whole number from 1 to 10."}, 400)
                    return
                if not db.execute("SELECT 1 FROM anime WHERE id=?", (anime_id,)).fetchone():
                    self.json_response({"error": "Anime not found."}, 404)
                    return
                stamp = now_iso()
                db.execute(
                    """INSERT INTO ratings(user_id,anime_id,score,created_at,updated_at) VALUES (?,?,?,?,?)
                    ON CONFLICT(user_id,anime_id) DO UPDATE SET score=excluded.score,updated_at=excluded.updated_at""",
                    (uid, anime_id, score, stamp, stamp),
                )
                db.commit()
                aggregate = db.execute(
                    "SELECT ROUND(AVG(score),1) avg,COUNT(*) count FROM ratings WHERE anime_id=?", (anime_id,)
                ).fetchone()
                self.json_response({"ok": True, "score": score, "average": aggregate["avg"], "count": aggregate["count"]})
                return
            match = re.fullmatch(r"/api/list/(\d+)", path)
            if match:
                anime_id = int(match.group(1)); status = str(payload.get("status", ""))
                allowed = {"Watching", "Planning", "Completed", "Dropped"}
                if status not in allowed:
                    self.json_response({"error": "Invalid list status."}, 400)
                    return
                db.execute(
                    """INSERT INTO watchlist(user_id,anime_id,status,updated_at) VALUES (?,?,?,?)
                    ON CONFLICT(user_id,anime_id) DO UPDATE SET status=excluded.status,updated_at=excluded.updated_at""",
                    (uid, anime_id, status, now_iso()),
                )
                db.commit()
                self.json_response({"ok": True, "status": status})
                return
            self.json_response({"error": "Not found"}, 404)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default=os.environ.get("HOST", "0.0.0.0"))
    parser.add_argument("--port", type=int, default=int(os.environ.get("PORT", "8000")))
    args = parser.parse_args()
    init_db()
    server = ThreadingHTTPServer((args.host, args.port), Handler)
    print(f"AnimeVerse running at http://{args.host}:{args.port}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
