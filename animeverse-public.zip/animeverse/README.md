# AnimeVerse

AnimeVerse is an original anime discovery and community-rating website. It uses a neon blue/purple visual system, a responsive catalog, shared 1–10 scores, watchlists, activity, and persistent user accounts.

## Run locally

AnimeVerse only needs Python 3. No packages or npm install are required.

```bash
cd animeverse
python server.py --host 0.0.0.0 --port 8000
```

Then open `http://localhost:8000`.

On a Chromebook, run the same commands in the Linux Terminal. Keep the terminal window open while using the site.

## Demo account

- Username: `nova`
- Password: `demo123`

You can also register a new account from the site. Account sessions, ratings, and watchlists are stored in `animeverse.db`.

## Features

- Responsive original anime catalog with search, genres, and sorting
- Community rankings built from shared SQLite ratings
- Registration, login, persistent secure session cookies, and logout
- Interactive whole-number ratings from 1–10
- Watching, Planning, Completed, and Dropped lists
- Profile statistics and recent community activity
- Twelve original fictional series and original cover/hero artwork

## Project layout

- `server.py` — standard-library HTTP server, REST API, authentication, and SQLite database
- `index.html` — browser entry point
- `static/styles.css` — responsive neon interface
- `static/app.js` — frontend application and API integration
- `static/covers/` — original SVG cover artwork

## Notes

This first version is designed as a self-contained local/community demo. For a larger public production deployment, add rate limiting, account recovery, moderation, and a managed database.

## Publish with Railway

Deployment files are included (`Dockerfile` and `railway.toml`).

1. Put this folder in a GitHub repository.
2. In Railway, choose **New Project → Deploy from GitHub repo** and select the repository.
3. After the first deployment, open the service settings and add a persistent **Volume** mounted at `/data`. The server automatically stores `animeverse.db` on the Railway volume.
4. Open **Settings → Networking → Generate Domain**.
5. Share the generated `*.up.railway.app` HTTPS address.

Do not upload the local `animeverse.db`; it is excluded by `.gitignore` and `.dockerignore`. The public deployment will create a fresh database and seed the original catalog automatically.
